Term Project readme file

To compile the code, user must enter "make" at first. to run the code,
then user must enter "make run".to delete and recompile user must entet "make clean".
Once the user enters "make run", the program will ask user to choose between 1 and 2, 
with 1 being run the program and 2 being exit the program. if the user selects 1 they will
asked to enter a word. if the word exist the program should return true and also reture 
words with the same first two indexes, it will aslo return how many micro seconds it took
for the program to finish running. if the word doesn't exist the program should check mispelling
if the word is mispelled it should suggest the correct word. if the word doesn't exist it should return
false. if the user enter number 2 the program should just quit.